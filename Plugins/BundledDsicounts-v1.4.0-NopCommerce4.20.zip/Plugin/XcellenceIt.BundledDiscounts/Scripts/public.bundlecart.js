﻿// *************************************************************************
// *                                                                       *
// * Bundled Discounts Plugin for nopCommerce                              *
// * Copyright (c) Xcellence-IT. All Rights Reserved.                      *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@nopaccelerate.com                                         *
// * Website: http://www.nopaccelerate.com                                 *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This  software is furnished  under a license  and  may  be  used  and *
// * modified  only in  accordance with the terms of such license and with *
// * the  inclusion of the above  copyright notice.  This software or  any *
// * other copies thereof may not be provided or  otherwise made available *
// * to any  other  person.   No title to and ownership of the software is *
// * hereby transferred.                                                   *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms  or  disassemble this software product or software product *
// * license.  Xcellence-IT may terminate this license if you don't comply *
// * with  any  of  the  terms and conditions set forth in  our  end  user *
// * license agreement (EULA).  In such event,  licensee  agrees to return *
// * licensor  or destroy  all copies of software  upon termination of the *
// * license.                                                              *
// *                                                                       *
// * Please see the  License file for the full End User License Agreement. *
// * The  complete license agreement is also available on  our  website at * 
// * http://www.nopaccelerate.com/enterprise-license                       *
// *                                                                       *
// *************************************************************************

/*
** bundle cart implementation
*/

var BundleCart = {
    loadWaiting: false,
    usepopupnotifications: false,
    topcartselector: '',
    topwishlistselector: '',
    flyoutcartselector: '',

    init: function (usepopupnotifications, topcartselector, topwishlistselector, flyoutcartselector) {
        this.loadWaiting = false;
        this.usepopupnotifications = usepopupnotifications;
        this.topcartselector = topcartselector;
        this.topwishlistselector = topwishlistselector;
        this.flyoutcartselector = flyoutcartselector;
    },

    setLoadWaiting: function (display) {
        displayAjaxLoading(display);
        this.loadWaiting = display;
    },

    //add a product to the cart/wishlist from the product details page
    addproducttocart_details: function (urladd, formselector) {
        if (this.loadWaiting != false) {
            return;
        }
        this.setLoadWaiting(true);
        $.ajax({
            cache: false,
            url: urladd,
            data: $(formselector).serialize(),
            type: 'post',
            success: this.success_process,
            complete: this.resetLoadWaiting,
            error: this.ajaxFailure
        });
    },

    success_process: function (response) {
        if (response.updatetopcartsectionhtml) {
            $(BundleCart.topcartselector).html(response.updatetopcartsectionhtml);
        }
        if (response.updatetopwishlistsectionhtml) {
            $(BundleCart.topwishlistselector).html(response.updatetopwishlistsectionhtml);
        }
        if (response.updateflyoutcartsectionhtml) {
            $(BundleCart.flyoutcartselector).replaceWith(response.updateflyoutcartsectionhtml);
        }
        //Feature #31114
        if (!response.hasAttributes) {
            BundleCart.displayQuickViewPopup(response.bundleId);
        }
        if (response.hasAttributes) {
            BundleCart.displayAttributePopup(response.bundleId);
        }
        if (response.message) {
            //display notification
            if (response.success === true) {
                if ($("#attributePopup").hasClass("ui-dialog-content") && $('#attributePopup').dialog('isOpen')) {
                    $("#attributePopup").dialog("close");
                    $('#attributePopup').html("");
                    $(".bg-overlay").hide();
                }
            }
            else {
                //error
                if (BundleCart.usepopupnotifications === true) {
                    displayPopupNotification(response.message, 'error', true);
                }
                else {
                    //no timeout for errors
                    displayBarNotification(response.message, 'error', 0);
                }
            }
            return false;
        }
        if (response.redirect) {
            location.href = response.redirect;
            return true;
        }
        return false;
    },

    //display popup window for product attributes
    displayAttributePopup: function (id) {
        $.ajax({
            url: AttributePopupUrl.Url,
            data: { bundleId: id },
            dataType: "html",
            success: function (data) {
                setTimeout(function () {
                    $('#attributePopup').html(data);
                    $("#attributePopup").dialog({
                        title: "Configure Bundle",

                        show: { effect: 'fade', duration: 450 },
                        hide: { effect: 'fade', duration: 450 },
                        close: function (event, ui) {
                            $(".bg-overlay").hide();
                        }
                    });
                    $("<div class='bg-overlay'></div>").insertBefore(".ui-dialog");
                }, 100);
            }
        });
    },

    //display Quick View popup window
    displayQuickViewPopup: function (id) {
        $.ajax({
            url: QuickViewPopupUrl.Url,
            data: { bundleId: id },
            dataType: "html",
            success: function (data) {
                setTimeout(function () {
                    $('#quickviewPopup').html(data);
                    $("#quickviewPopup").dialog({
                        title: "JUST ADDED TO YOUR BASKET",

                        show: { effect: 'fade', duration: 450 },
                        hide: { effect: 'fade', duration: 450 },
                        close: function (event, ui) {
                            $(".bg-overlay").hide();
                        }
                    });
                    $("<div class='bg-overlay'></div>").insertBefore(".ui-dialog");
                }, 100);
            }
        });
    },

    resetLoadWaiting: function () {
        BundleCart.setLoadWaiting(false);
    },

    ajaxFailure: function () {
        alert('Failed to add the product. Please refresh the page and try one more time.');
    }
};